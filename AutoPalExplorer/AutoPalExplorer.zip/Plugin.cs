﻿using System;
using Dalamud.Game.Command;
using Dalamud.Game.Text;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using System.Numerics;
using Dalamud.Interface;
using Dalamud.Bindings.ImGui;
using AutoPalExplorer.Services;

namespace AutoPalExplorer;

public sealed class Plugin : IDalamudPlugin
{
    public string Name => "AutoPalExplorer";
    private const string Command = "/autopal";

    [PluginService] internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] internal static IClientState ClientState { get; private set; } = null!;
    [PluginService] internal static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] internal static IFramework Framework { get; private set; } = null!;
    [PluginService] internal static IPluginLog Log { get; private set; } = null!;
    [PluginService] internal static IObjectTable ObjectTable { get; private set; } = null!;
    [PluginService] internal static IChatGui ChatGui { get; private set; } = null!;
    [PluginService] internal static ICondition Condition { get; private set; } = null!;

    private bool configWindowVisible = false;
    private readonly Configuration config;
    private readonly AutoPalController controller;

    public Plugin()
    {
        // 加载配置
        config = PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
        config.Initialize(PluginInterface);

        // 依赖
        var vnavmesh = new VNavmeshClient(PluginInterface, Log);
        var navigator = new Navigator(ClientState, vnavmesh, Log);
        var exitDetector = new ExitDetector(ObjectTable, Log);
        var wallFollower = new WallFollower(ClientState, navigator, Log);

        controller = new AutoPalController(
            ClientState,
            navigator,
            exitDetector,
            wallFollower,
            ObjectTable,
            CommandManager,
            Condition,
            Log,
            config
        );

        // 注册命令
        CommandManager.AddHandler(Command, new CommandInfo(OnCommand)
        {
            HelpMessage = "Auto Palace explorer. /autopal [start|stop|toggle]"
        });

        // 注册UI
        PluginInterface.UiBuilder.Draw += DrawUi;
        PluginInterface.UiBuilder.OpenConfigUi += ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi += ToggleConfigUi;

        // 每帧更新
        Framework.Update += OnFrameworkUpdate;

        // 监听聊天，用于“传送装置已激活”
        ChatGui.ChatMessage += OnChatMessage;

        // 可选：默认开启
        if (config.EnabledByDefault)
            controller.Start();

        if (config.devMode)
            Log.Information("[AutoPalExplorer] Loaded.");
    }

    private void OnFrameworkUpdate(IFramework framework)
    {
        controller.Update();
    }

    private void OnCommand(string command, string args)
    {
        var arg = args.Trim().ToLowerInvariant();

        switch (arg)
        {
            case "start":
                controller.Start();
                ChatGui.Print("[AutoPalExplorer] Started.");
                break;

            case "stop":
                controller.Stop();
                ChatGui.Print("[AutoPalExplorer] Stopped.");
                break;
            case "config":
                configWindowVisible = true;
                break;
            case "toggle":
            case "":
                if (controller.IsRunning)
                {
                    controller.Stop();
                    ChatGui.Print("[AutoPalExplorer] Stopped.");
                }
                else
                {
                    controller.Start();
                    ChatGui.Print("[AutoPalExplorer] Started.");
                }
                break;

            default:
                ChatGui.Print("[AutoPalExplorer] Usage: /autopal [start|stop|toggle]");
                break;
        }
    }

    // 必须精确匹配 IChatGui.OnMessageDelegate:
    // (XivChatType type, int timestamp, ref SeString sender, ref SeString message, ref bool isHandled)
    private void OnChatMessage(
        XivChatType type,
        int timestamp,
        ref SeString sender,
        ref SeString message,
        ref bool isHandled)
    {
        var text = message.TextValue;
        if (string.IsNullOrEmpty(text))
            return;

        // 这里匹配你游戏里的实际提示文本
        if (text.Contains("传送装置启动了", StringComparison.OrdinalIgnoreCase)
            || text.Contains("Cairn of Passage is activated", StringComparison.OrdinalIgnoreCase)
            || text.Contains("Cairn of Passage has been activated", StringComparison.OrdinalIgnoreCase))
        {
            controller.NotifyExitActivated();
        }
    }

    public void Dispose()
    {
        Framework.Update -= OnFrameworkUpdate;
        CommandManager.RemoveHandler(Command);
        ChatGui.ChatMessage -= OnChatMessage;

        // UI
        PluginInterface.UiBuilder.Draw -= DrawUi;
        PluginInterface.UiBuilder.OpenConfigUi -= ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi -= ToggleConfigUi;

        controller.Stop();
        if (config.devMode)
            Log.Information("[AutoPalExplorer] Disposed.");
    }
    private void ToggleConfigUi()
    {
        configWindowVisible = !configWindowVisible;
    }

    private void DrawUi()
    {
        if (!configWindowVisible)
            return;

        ImGui.SetNextWindowSize(new Vector2(420, 260), ImGuiCond.FirstUseEver);

        if (!ImGui.Begin("AutoPalExplorer", ref configWindowVisible,
                ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.End();
            return;
        }

        // 标题
        ImGui.TextUnformatted("Auto Palace Explorer");

        // Start / Stop 按钮
        if (controller.IsRunning)
        {
            if (ImGui.Button("Stop##autopal"))
                controller.Stop();
        }
        else
        {
            if (ImGui.Button("Start##autopal"))
                controller.Start();
        }

        ImGui.Separator();
        ImGui.TextUnformatted("战斗设置:");

        // BMRAI 控制
        bool useBmrai = config.UseBmrai;
        if (ImGui.Checkbox("用BossMod和Rotation来自动打怪", ref useBmrai))
        {
            config.UseBmrai = useBmrai;
            config.Save();
        }

        ImGui.Separator();
        ImGui.TextUnformatted("箱子设置:");

        bool openBronze = config.OpenBronzeChests;
        if (ImGui.Checkbox("开启铜箱子", ref openBronze))
        {
            config.OpenBronzeChests = openBronze;
            config.Save();
        }

        bool openSilver = config.OpenSilverChests;
        if (ImGui.Checkbox("开启银箱子", ref openSilver))
        {
            config.OpenSilverChests = openSilver;
            config.Save();
        }

        bool openGold = config.OpenGoldChests;
        if (ImGui.Checkbox("开启金箱子", ref openGold))
        {
            config.OpenGoldChests = openGold;
            config.Save();
        }

        ImGui.Separator();
        ImGui.TextUnformatted("其他:");
        bool devModeStatus = config.devMode;
        if (ImGui.Checkbox("开发者(拉屎)模式", ref devModeStatus))
        {
            config.devMode = devModeStatus;
            config.Save();
        }

        ImGui.End();
    }
}
