using System;
using System.Numerics;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.Object;

using AutoPalExplorer.Helpers;

namespace AutoPalExplorer.Services;

public sealed class AutoPalController
{
    private readonly IClientState clientState;
    private readonly Navigator navigator;
    private readonly ExitDetector exitDetector;
    private readonly WallFollower wallFollower;
    private readonly IObjectTable objectTable;
    private readonly ICommandManager commandManager;
    private readonly ICondition condition;
    private readonly IPluginLog log;
    private readonly Configuration config;

    public bool IsRunning { get; private set; }

    private bool bmraiOn;
    private uint lastTerritoryType;

    private const float ExitStopRadius = 1.0f;
    private const float ChestDoneRadius = 2.0f;
    private const float InactiveExitNearRadius = 6.0f;
    private const float EnemySearchRadius = 500.0f;

    private DateTime lastChestInteractAt = DateTime.MinValue;
    private const int ChestInteractIntervalMs = 500;

    public AutoPalController(
        IClientState clientState,
        Navigator navigator,
        ExitDetector exitDetector,
        WallFollower wallFollower,
        IObjectTable objectTable,
        ICommandManager commandManager,
        ICondition condition,
        IPluginLog log,
        Configuration config)
    {
        this.clientState = clientState;
        this.navigator = navigator;
        this.exitDetector = exitDetector;
        this.wallFollower = wallFollower;
        this.objectTable = objectTable;
        this.commandManager = commandManager;
        this.condition = condition;
        this.log = log;
        this.config = config;
    }

    public void Start()
    {
        if (IsRunning)
            return;

        if (clientState.LocalPlayer is null)
        {
            log.Warning("[AutoPalExplorer] Cannot start: no local player.");
            return;
        }

        IsRunning = true;
        lastTerritoryType = clientState.TerritoryType;
        wallFollower.Reset();
        exitDetector.Reset();
        navigator.Stop();
        EnsureBmraiOff();
        if (config.devMode)
            log.Information("[AutoPalExplorer] Started.");
    }

    public void Stop()
    {
        if (!IsRunning)
            return;

        IsRunning = false;
        navigator.Stop();
        EnsureBmraiOff();
        if (config.devMode)
            log.Information("[AutoPalExplorer] Stopped.");
    }

    /// <summary>
    /// 从插件 OnChatMessage 调用，当聊天出现“传送装置已激活”等信息时。
    /// </summary>
    public void NotifyExitActivated()
    {
        exitDetector.MarkExitActivated();
    }

    public void Update()
    {
        if (!IsRunning)
            return;

        var player = clientState.LocalPlayer;
        if (player is null)
        {
            Stop();
            return;
        }

        // 如果不在妖宫则结束
        if (!MapIds.IsPilgrimsTraverse(clientState.TerritoryType))
        {
            Stop();
            if (config.devMode)
                log.Information("不在妖宫");
            return;
        }

        // 0. Territory 变化视为换层/换图，重置状态（对深宫不是完美但安全）
        if (clientState.TerritoryType != lastTerritoryType)
        {
            lastTerritoryType = clientState.TerritoryType;
            wallFollower.Reset();
            exitDetector.Reset();
            navigator.Stop();
            EnsureBmraiOff();
            if (config.devMode)
                log.Information("[AutoPalExplorer] Territory changed, state reset.");
        }

        var pos = player.Position;

        // 1. 战斗状态：交给 BMRAI，暂停导航
        var inCombat = condition[ConditionFlag.InCombat];
        if (inCombat)
        {
            if (!bmraiOn)
                EnsureBmraiOn();

            navigator.Stop();
            return;
        }
        else
        {
            if (bmraiOn)
                EnsureBmraiOff();
        }

        // 2. 更新导航状态 + 目标感知
        navigator.Update();
        exitDetector.Update(pos);

        var currentTarget = navigator.CurrentTarget;

        // 3. 优先级决策
        // ==== 3.1 宝箱（次优，出现就抢占 wall follower 的路） ====
        if (exitDetector.HasChest && exitDetector.Chest is { } chest)
        {
            if (!ShouldOpenChest(chest.BaseId))
            {

            }
            else
            {
                if (chest.IsTargetable)
                {
                    var dx = chest.Position.X - pos.X;
                    var dz = chest.Position.Z - pos.Z;
                    var distSq = dx * dx + dz * dz;

                    // 还没到箱子旁边
                    if (distSq > ChestDoneRadius * ChestDoneRadius)
                    {
                        // log.Information(distSq.ToString());
                        // log.Information("还没到箱子边");
                        // 当前没有目标，或者当前目标不是这个箱子 → 打断并改为去箱子
                        if (IsDifferentTarget(currentTarget, chest.Position, 1.0f))
                        {
                            navigator.Stop();
                            navigator.TryMoveTo(chest.Position);
                        }
                        return;
                    }
                    else
                    {
                        if (config.devMode)
                            log.Information("开个箱子");
                        TryOpenChest(chest);
                    }
                    // 已经在箱子旁边：继续看其他优先级
                }
            }
        }

        // ==== 3.2 激活传送装置（最高优先级，打断一切） ====
        if (exitDetector.HasActiveExit && exitDetector.Exit is { } activeExit)
        {
            var dx = activeExit.Position.X - pos.X;
            var dz = activeExit.Position.Z - pos.Z;
            var distSq = dx * dx + dz * dz;

            // 已经在门口：停导航，等待手动交互，不停止控制器，这样换层还能继续
            // if (config.devMode)
            //     log.Information(distSq.ToString());
            if (distSq <= ExitStopRadius * ExitStopRadius)
            {
                if (navigator.IsBusy)
                    navigator.Stop();
                return;
            }

            // 目标不是这个 exit，或者当前没目标 → 打断并改为去 exit
            if (!navigator.IsBusy || IsDifferentTarget(currentTarget, activeExit.Position, 1.0f))
            {
                navigator.Stop();
                navigator.TryMoveTo(activeExit.Position);
            }

            return;
        }

        // ==== 3.3 未激活传送装置（可选打断） ====
        if (exitDetector.HasInactiveExit && exitDetector.Exit is { } inactiveExit)
        {
            var dx = inactiveExit.Position.X - pos.X;
            var dz = inactiveExit.Position.Z - pos.Z;
            var distSq = dx * dx + dz * dz;

            if (!navigator.IsBusy || IsDifferentTarget(currentTarget, inactiveExit.Position, 1.0f))
            {
                // 不在附近就先走过去
                if (distSq > InactiveExitNearRadius * InactiveExitNearRadius)
                {
                    navigator.Stop();
                    navigator.TryMoveTo(inactiveExit.Position);
                    return;
                }
                else
                {
                    // 在传送装置附近：找怪去打，交给 BMRAI
                    var enemy = FindNearestEnemy(pos, EnemySearchRadius);
                    if (enemy is not null)
                    {
                        navigator.Stop();
                        navigator.TryMoveTo(enemy.Position);
                        return;
                    }
                }
            }
            // 如果正在走向 inactiveExit 且已经接近，就让它先走完；找不到怪就交给贴墙逻辑
        }

        // 3.4 没有更高优先级 & 当前没有在移动：靠墙探索
        if (!navigator.IsBusy)
        {
            if (!wallFollower.TryStep())
            {
                log.Warning("[AutoPalExplorer] No further path to explore. Stopping.");
                Stop();
            }
        }
    }

    // ===== Utils =====

    private bool ShouldOpenChest(uint baseId)
    {
        if (ObjectIds.IsBronzeChest(baseId))
            return config.OpenBronzeChests;

        if (ObjectIds.IsSilverChest(baseId))
            return config.OpenSilverChests;

        if (ObjectIds.IsGoldChest(baseId))
            return config.OpenGoldChests;

        return false;
    }
    private unsafe void TryOpenChest(IGameObject chest)
    {
        if (!ShouldOpenChest(chest.BaseId))
            return;

        // log.Information("开箱逻辑");
        // 基本防呆
        if (chest == null)
        {
            if (config.devMode)
                log.Information("防呆");
            return;
        }

        // 如果箱子已经不能点了（被开过 / 动画中），就别管
        if (!chest.IsTargetable)
        {
            if (config.devMode)
                log.Information("被开过 / 动画中");
            return;
        }


        // 节流，避免每帧都发交互
        var now = DateTime.UtcNow;
        if ((now - lastChestInteractAt).TotalMilliseconds < ChestInteractIntervalMs)
            return;

        try
        {
            var ptr = (GameObject*)chest.Address;
            if (ptr == null)
                return;

            var ts = TargetSystem.Instance();
            if (ts == null)
                return;

            ts->InteractWithObject(ptr, false);
            lastChestInteractAt = now;
            if (config.devMode)
                log.Information("[AutoPalExplorer] Interact with chest at {X}, {Y}, {Z}.",
                chest.Position.X, chest.Position.Y, chest.Position.Z);
        }
        catch (Exception ex)
        {
            log.Warning($"[AutoPalExplorer] Failed to interact with chest: {ex.Message}");
        }
    }
    private static bool IsDifferentTarget(Vector3? current, Vector3 desired, float threshold)
    {
        if (current is null)
            return true;

        var v = current.Value;
        var dx = v.X - desired.X;
        var dz = v.Z - desired.Z;
        return dx * dx + dz * dz > threshold * threshold;
    }

    private void EnsureBmraiOn()
    {
        if (!config.UseBmrai)
            return;

        if (bmraiOn)
            return;
        
        bmraiOn = true;
        TryCommand("/bmrai on");
        TryCommand("/rotation Auto");
        if (config.devMode)
            log.Information("[AutoPalExplorer] BMRAI ON.");
    }

    private void EnsureBmraiOff()
    {
        if (!bmraiOn)
            return;

        bmraiOn = false;
        TryCommand("/bmrai off");
        TryCommand("/rotation Off");
        if (config.devMode)
            log.Information("[AutoPalExplorer] BMRAI OFF.");
    }

    private void TryCommand(string command)
    {
        try
        {
            commandManager.ProcessCommand(command);
        }
        catch (Exception ex)
        {
            log.Warning($"[AutoPalExplorer] Failed to execute command '{command}': {ex.Message}");
        }
    }

    private IBattleChara? FindNearestEnemy(Vector3 from, float maxDistance)
    {
        IBattleChara? best = null;
        var bestDistSq = maxDistance * maxDistance;

        foreach (var obj in objectTable)
        {
            if (obj is not IBattleChara bc)
                continue;

            if (bc.ObjectKind != Dalamud.Game.ClientState.Objects.Enums.ObjectKind.BattleNpc)
                continue;
            if (!bc.IsTargetable || bc.CurrentHp <= 0)
                continue;

            var dx = bc.Position.X - from.X;
            var dz = bc.Position.Z - from.Z;
            var distSq = dx * dx + dz * dz;

            if (distSq < bestDistSq)
            {
                bestDistSq = distSq;
                best = bc;
            }
        }

        return best;
    }
}
