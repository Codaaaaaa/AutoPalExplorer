using System.Collections.Generic;

namespace AutoPalExplorer.Helpers
{
    /// <summary>
    /// 存放与地宫对象相关的 DataId 集合。
    /// 包含传送装置、宝箱等的 ID。
    /// </summary>
    public static class ObjectIds
    {
        /// <summary>
        /// 传送装置 DataId（Exit）
        /// </summary>
        public static readonly HashSet<uint> exitIds = new()
        {
            2014756u, // 传送装置
        };

        /// <summary>
        /// 宝箱 DataId（Chest）
        /// </summary>

        // 铜宝箱
        public static readonly HashSet<uint> BronzeChestIds = new()
        {
            1881u,
            1882u,
            1883u,
            1884u,
            1885u,
            1886u,
            1887u,
            1888u,
            1889u,
            1890u,
            1891u,
            1892u,
            1893u,
            1906u,
            1907u,
            1908u,
        };

        // 银宝箱
        public static readonly HashSet<uint> SilverChestIds = new()
        {
            2007357u,
        };

        // 金宝箱
        public static readonly HashSet<uint> GoldChestIds = new()
        {
            2007358u,
        };
        
        public static bool IsBronzeChest(uint baseId)
            => BronzeChestIds.Contains(baseId);

        public static bool IsSilverChest(uint baseId)
            => SilverChestIds.Contains(baseId);

        public static bool IsGoldChest(uint baseId)
            => GoldChestIds.Contains(baseId);

        public static bool IsAnyChest(uint baseId)
            => IsBronzeChest(baseId) || IsSilverChest(baseId) || IsGoldChest(baseId);
    }
}
